#!/bin/bash
workdir=$(x=1; pwd)
