#!../../bash
#$Id: restartbug.sh,v 1.1 2008/08/22 18:54:08 rockyb Exp $

x=1
cd /
y=2
z=0
