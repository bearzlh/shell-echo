#!/bin/zsh
# For testing break, delete, step, step+ step-, default step and set force.
for ((i=0; i<3; i++)) do echo 1st loop $i ; done
for ((i=0; i<3; i++)) do echo 2nd loop $i ; done
for ((i=0; i<3; i++)) do echo 3rd loop $i ; done
for ((i=0; i<3; i++)) do echo 4th loop $i ; done
for ((i=0; i<3; i++)) do echo 5th loop $i ; done
for ((i=0; i<3; i++)) do echo 6th loop $i ; done
