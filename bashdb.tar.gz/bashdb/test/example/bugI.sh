#!/bin/bash

for i in /bin /etc; do
    echo $i
done
